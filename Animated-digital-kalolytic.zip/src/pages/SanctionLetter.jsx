import React from 'react'

function SanctionLetter() {
  return (
    <div>SanctionLetter</div>
  )
}

export default SanctionLetter